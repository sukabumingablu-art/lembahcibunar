# 🌿 Lembah Cibunar Camping Ground Website

Website sederhana untuk memperkenalkan Lembah Cibunar Camping Ground.

## Cara Upload ke GitHub Pages
1. Buat repository baru di GitHub, misalnya `lembahcibunar`.
2. Upload file `index.html` dan `README.md` ke repository.
3. Masuk ke menu **Settings > Pages** di repo tersebut.
4. Pilih branch `main` dan folder `/ (root)` lalu klik Save.
5. Tunggu beberapa menit, website akan tersedia di:

```
https://USERNAME.github.io/lembahcibunar
```

---
© 2025 Lembah Cibunar
